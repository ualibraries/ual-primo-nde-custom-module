import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

/**
 * EXERCISE 1 - a static component.
 * Hooked to 'nde-search-filters-side-nav-before' in customComponentMappings.ts,
 * so it appears above the filter panel on the search results page.
 * No record data, no services: just HTML + CSS.
 */
@Component({
  selector: 'ua-help-box',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './ua-help-box.component.html',
  styleUrls: ['./ua-help-box.component.scss'],
})
export class UaHelpBoxComponent {
  // Try it: change this text, rebuild, refresh.
  title = 'Not finding what you need?';

  links = [
    { label: 'Search specific databases', url: 'https://libguides.library.arizona.edu/az/databases' },
    { label: 'Request through interlibrary loan', url: 'https://lib.arizona.edu/borrow/request/interlibrary-loan' },
    { label: 'Ask a librarian', url: 'https://ask.library.arizona.edu/' },
  ];
}
