import { TestBed } from '@angular/core/testing';
import { UaHelpBoxComponent } from './ua-help-box.component';

describe('UaHelpBoxComponent', () => {
  it('renders links with real hrefs', () => {
    const fixture = TestBed.configureTestingModule({ imports: [UaHelpBoxComponent] }).createComponent(UaHelpBoxComponent);
    fixture.detectChanges();
    const hrefs = Array.from(fixture.nativeElement.querySelectorAll('a')).map((a: any) => a.getAttribute('href'));
    console.log('HELP_HREFS=' + JSON.stringify(hrefs));
    expect(hrefs.length).toBe(3);
    hrefs.forEach(h => expect(h).toMatch(/^https:\/\//));
  });
});
