import { UaHelpBoxComponent } from '../ua-help-box/ua-help-box.component';
import { UaRecordInfoComponent } from '../ua-record-info/ua-record-info.component';
import { UaExternalSearchComponent } from '../ua-external-search/ua-external-search.component';

// Left side: the NDE hook (an existing NDE element name + -before / -after / -top / -bottom).
// Right side: your component. Each hook can hold one component.
export const selectorComponentMap = new Map<string, any>([
  ['nde-search-filters-side-nav-top', UaExternalSearchComponent],     // inside the filters panel
  ['nde-search-filters-side-nav-after', UaHelpBoxComponent],   // moved from -before
  ['nde-record-availability-bottom', UaRecordInfoComponent],
]);
