import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

/**
 * EXERCISE 2 - reading record data from the host component.
 * Hooked to 'nde-record-availability-bottom', so it renders under the
 * availability line of every search result.
 *
 * NDE passes in the component you are attached to as `hostComponent`.
 * For record-level hooks, the record is at hostComponent.searchResult,
 * and its PNX is at hostComponent.searchResult.pnx
 * (same shape as classic Primo: pnx.addata.oclcid, pnx.control.recordid, ...).
 */
@Component({
  selector: 'ua-record-info',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './ua-record-info.component.html',
  styleUrls: ['./ua-record-info.component.scss'],
})
export class UaRecordInfoComponent {
  @Input() hostComponent: any;

  // Turn this off once you've seen the data shape in the console.
  private debug = true;

  /** All OCLC numbers on the record, digits only, de-duplicated. */
  get oclcNumbers(): string[] {
    const pnx = this.hostComponent?.searchResult?.pnx;
    if (this.debug && pnx) {
      console.log('[ua-record-info] pnx for', pnx?.control?.recordid?.[0], pnx);
      this.debug = false; // log once per result
    }
    const raw: string[] = pnx?.addata?.oclcid ?? [];
    const nums = raw.flatMap(v => [...String(v).matchAll(/\d{5,}/g)].map(m => m[0]));
    return [...new Set(nums)];
  }
}
